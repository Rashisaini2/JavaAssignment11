public class Calculator {
    double height,weight;
    public void BMI(double height, double weight) {
        double BMI = weight / (height * height);

        System.out.println(" The Body Mass Index (BMI) is " + BMI + " kg/m2");
    }
    }



